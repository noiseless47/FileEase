import requests
import csv
import time
import random

# Config for the new link
challenge_id = "328025"
round_type = "assessmentnewround"
per_page = 30
timestamp = 1752585617
total_teams = 2000  # ⚠️ <- set actual total here
total_pages = (total_teams // per_page) + 1

base_url = f"https://unstop.com/api/public/live-leaderboard/{challenge_id}/{round_type}"

user_agents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:109.0)",
    "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:91.0)",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X)",
]

headers_base = {
    "Accept": "application/json",
    "Referer": "https://unstop.com/",
}

results = []

for page in range(1, total_pages + 1):
    url = f"{base_url}?page={page}&per_page={per_page}&filterName=timestamp&filterValue={timestamp}&undefined=true"
    success = False

    for attempt in range(3):  # retry up to 3 times
        headers = headers_base.copy()
        headers["User-Agent"] = random.choice(user_agents)

        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            data = response.json().get("data", {}).get("data", [])

            for entry in data:
                team_info = entry.get("team", {})
                team_name = team_info.get("team_name", "")
                players = team_info.get("players", [])
                player_names = [p.get("name", "") for p in players]
                player_orgs = [p.get("organisation", "") for p in players]

                results.append({
                    "team_name": team_name,
                    "players": ", ".join(player_names),
                    "organisations": ", ".join(set(player_orgs)),
                })

            print(f"✅ Page {page}/{total_pages}")
            success = True
            break

        elif response.status_code == 403:
            print(f"🚫 403 at page {page}, attempt {attempt+1}. Retrying in 5s...")
            time.sleep(5)
        else:
            print(f"⚠️ Status {response.status_code} at page {page}. Retry in 10s...")
            time.sleep(10)

    if not success:
        print(f"❌ Skipped page {page} after 3 failed attempts.")
        continue

    time.sleep(random.uniform(0.5, 1.2))  # faster but respectful

    # Save every 50 pages
    if page % 50 == 0 or page == total_pages:
        with open("unstop_leaderboard_partial.csv", "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["team_name", "players", "organisations"])
            writer.writeheader()
            writer.writerows(results)
        print(f"💾 Saved after page {page}")

# Final save
with open("unstop_leaderboard_final.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=["team_name", "players", "organisations"])
    writer.writeheader()
    writer.writerows(results)

print(f"\n🏁 Done. {len(results)} teams saved to 'unstop_leaderboard_final.csv'")
